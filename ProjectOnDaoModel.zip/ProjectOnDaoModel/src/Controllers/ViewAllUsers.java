package Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.Dao;
import Model.RegisterModel;

public class ViewAllUsers extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
{
PrintWriter out=res.getWriter();
RegisterModel rm= new RegisterModel();


rm.setName(req.getParameter("t1"));
rm.setEmail(req.getParameter("t2"));
rm.setPwd(req.getParameter("t3"));
rm.setMobile(Long.parseLong(req.getParameter("t4")));
rm.setAdr(req.getParameter("t5"));
ResultSet rs=null;
rs=new Dao().viewAll(rm);

try {
	out.print("<table border=3 cellpadding=7><tr bgcolor=yellow><td>name</td><td>Email Id</td><td>Password</td><td>mobile</td><td>city</td><td>updateuser</td><td>deleteuser</td></tr>");
	
	while(rs.next())
	{
		out.print("<body><tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getLong(4)+"</td><td>"+rs.getString(5)+"</td><td><a href=requpdate?id="+rs.getString(1)+">Update</a></td><td><a href=reqdelete?t1="+rs.getString(1)+">delete</a></td></tr>");
	}
} catch (SQLException e)
{
	out.print(e);
}


}}
















