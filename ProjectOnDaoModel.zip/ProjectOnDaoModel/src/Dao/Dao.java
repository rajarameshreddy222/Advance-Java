package Dao;

import java.sql.Statement;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Model.LoginModel;
import Model.RegisterModel;

public class Dao 
{ 
static Connection con=null;
public  static Connection getConnectionObject() 
{
	try {
		
		Class.forName("org.h2.Driver");
		con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/raja","sa","sa");	
	}
	catch(Exception e ) {System.out.println(e);}
	return con;}
public int register(RegisterModel rm)
{int i=0;
con=Dao.getConnectionObject();
try {
	  PreparedStatement pstmt=con.prepareStatement("insert into one values(?,?,?,?,?)");
	  pstmt.setString(1,rm.getName());
	  pstmt.setString(2,rm.getEmail());
	  pstmt.setString(3,rm.getPwd());
	  pstmt.setLong(4,rm.getMobile());
	  pstmt.setString(5,rm.getAdr());
	  i=pstmt.executeUpdate();
	  
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
	return i;
	}
public ResultSet login(RegisterModel rm)
    {
      ResultSet rs=null;
   con=Dao.getConnectionObject();
	  try 
	  {
		  Statement st=con.createStatement();
		   rs=st.executeQuery("select name,pwd from one where name='"+rm.getName()+"' and pwd='"+rm.getPwd()+"'");
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
	  return rs;
   }
public ResultSet viewAll(RegisterModel rm) 
{
	ResultSet rs=null;

con=Dao.getConnectionObject();
	  try 
	  {
		  Statement st=con.createStatement();
		   rs=st.executeQuery("select * from one");
		   
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
	return rs;
	}
public int Delete(RegisterModel rm)
{
	int i=0;
	con=Dao.getConnectionObject();
	try{
		PreparedStatement pstmt=con.prepareStatement("delete form one where name='"+rm.getName()+"'");
	}
	catch(Exception e){System.out.println(e);
		
	}
	return i;
}

public int update(RegisterModel rm) 
   {
	
	
	int i=0;
	con=Dao.getConnectionObject();
	try{
		String getAdr;
		PreparedStatement pstmt=con.prepareStatement("update one set email='"+rm.getEmail()+"',pwd='"+rm.getPwd()+"',mobile='"+rm.getMobile()+"',adr='"+rm.getAdr()+"' from where name='"+rm.getName()+"'");                                          
	}
	catch(Exception e) {System.out.println(e);}
	return i;
	




}

}














