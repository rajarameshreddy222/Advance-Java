import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateController extends HttpServlet {

	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
	Connection  con=null;
	int i=0;

	PrintWriter out=res.getWriter();

	try {
		Class.forName("org.h2.Driver");
		con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/raja","sa","sa");
		Statement st=con.createStatement();
		i=st.executeUpdate("update one set email='"+req.getParameter("t2")+"',pwd='"+req.getParameter("t3")+"',mobile='"+Long.parseLong(req.getParameter("t4"))+"',adr='"+req.getParameter("t5")+"'where name='"+req.getParameter("t1")+"'");                                                                      
		if(i>0)
		{

	    	RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
	    	rd.forward(req, res);
		}
		else
		{
			out.print("Update fail");
		}
		
	} catch (Exception e) {

		System.out.println(e);
	}

		
		
		
	}	
	}
