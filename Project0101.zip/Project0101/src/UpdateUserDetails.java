import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class UpdateUserDetails extends HttpServlet{
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		Connection con=null;
		ResultSet rs=null;
PrintWriter Out=res.getWriter();
	
		try {
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/raja","sa","sa");
			Statement stmt=con.createStatement();
		rs=stmt.executeQuery("select * from one ");
          if(rs.next())
            {
            	Out.print("<body><form action=update><table bgcolor=yellow border=7 cellpadding=5 ><tr><td>name:</td><td><input type=text  name=t1 readonly value="+rs.getString(1) +"> </td>");
    			Out.print("<tr><td>Email:    </td><td> <input      type=text name=t2         value="+rs.getString(2)+"></td> ");
    			Out.print("<tr><td>Pwd:       </td><td><input      type=text name=t3          value="+rs.getString(3)+"></td> ");
    			Out.print("<tr><td>MobileNO:  </td><td><input      type=text name=t4          value="+rs.getLong(4)+"></td> ");
    			Out.print("<tr><td>adr:      </td><td> <input      type=text name=t5          value="+rs.getString(5)+"></td> ");
    			Out.print("<tr><td><input type=submit value=Update></td><td><input type=Reset value=clear></td></form>");
    		}
            

	}
		catch(Exception e)
		{
			System.out.println(e);
		}

}}
