
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterController extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		PrintWriter out=res.getWriter();
		 String name=req.getParameter("t1");
		  String email=req.getParameter("t2");
		  String pwd=req.getParameter("t3");
		  long mobile=Long.parseLong(req.getParameter("t4"));
		  String adr=req.getParameter("t5");
		int i=0;
		  try {
		  Class.forName("org.h2.Driver");
		  Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/raja","sa","sa");
		  PreparedStatement pstmt=con.prepareStatement("insert into one values(?,?,?,?,?)");
		  pstmt.setString(1,name);
		  pstmt.setString(2,email);
		  pstmt.setString(3,pwd);
		  pstmt.setLong(4,mobile);
		  pstmt.setString(5,adr);
		  i= pstmt.executeUpdate();
		  if(i>0)
		  {

				RequestDispatcher rd=req.getRequestDispatcher("Register.html");
				rd.include(req, res);
				out.print("<center>Registration done successfully click here to open <a href=\"Login.html\"><h1>Login</h1></a>");
		  }
		  else
		  {

				RequestDispatcher rd=req.getRequestDispatcher("reg.html");
				rd.include(req, res);
				out.print("<center>Registration fail");
		  }
		  }
		  catch(Exception e)
		  {
		  System.out.println(e);
		  }
		   out.close();
	
	}
}
