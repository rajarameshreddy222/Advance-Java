import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Dao
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try {
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/raja","sa","sa");	
		    }
		   catch(Exception e)
		    {
			System.out.println(e);
		  }
		return con;
	}
	
	public boolean login(RegisterModel rm)
	{
		boolean b=false;
		
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try {
		Statement stmt=con.createStatement();
		rs=stmt.executeQuery("select name,pwd from one where name='"+rm.getName()+"' and pwd='"+rm.getPwd()+"'");
	
		if(rs.next())
		{
			b=true;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return b;
	}
	
	public boolean register(RegisterModel rm)
	{
		boolean b=false;
		int i=0;
		con=Dao.getConnectionObject();
		try {
			PreparedStatement pstmt=con.prepareStatement("insert into one values(?,?,?,?,?)");
			pstmt.setString(1,rm.getName());
			pstmt.setString(2, rm.getEmail());
			pstmt.setString(3, rm.getPwd());
			pstmt.setLong(4,rm.getMobile());
			pstmt.setString(5,rm.getAdr());
			i=pstmt.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	


public ResultSet viewAll(RegisterModel rm) throws Exception {
	ResultSet rs=null;
	con=Dao.getConnectionObject();
	Statement st=con.createStatement();
	rs=st.executeQuery(" select * from one");
			
	return rs;
	}

	public boolean delete(RegisterModel rm)

	{
		boolean b=false;
		con=Dao.getConnectionObject();
		int i=0;
		try
		{
			Statement stmt=con.createStatement();
			i=stmt.executeUpdate("delete from one  where name='"+rm.getName()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	
	public boolean update(RegisterModel rm) {
		boolean b=false;
		int i=0;
		con=Dao.getConnectionObject();
		try{
			PreparedStatement pstmt=con.prepareStatement("update one set email='"+rm.getEmail()+"',pwd='"+rm.getPwd()+"',mobile='"+rm.getMobile()+"',adr='"+rm.getAdr()+"' where name='"+rm.getName()+"'");                                          
                i=pstmt.executeUpdate();  
                if(i>0)
                {
                	b=true;
                }
		}
		catch(Exception e) {System.out.println(e);}
		
		
		
		return b;
		}
}