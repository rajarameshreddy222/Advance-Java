import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Controllers extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out=res.getWriter();
	String path=req.getServletPath();
	if(path.equals("/reqlogin"))
	{
		String name=req.getParameter("t1");
		String pwd=req.getParameter("t2");
		
		boolean b=new Dao().login(name,pwd);
		if(b)
		{
			RequestDispatcher rd=req.getRequestDispatcher("Welcome.html");
			rd.include(req, res);
		 
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("login.html");
			rd.include(req, res);
			out.print("<center>Invalid username /password"); 
		}
	}
	else if(path.equals("/reqreg"))
	{
		String name=req.getParameter("t1");
		String pwd=req.getParameter("t3");		
		String email=req.getParameter("t2");		
		long mobile=Long.parseLong(req.getParameter("t4"));
		String adr=req.getParameter("t5");
		boolean b=new Dao().register(name,email,pwd,mobile, adr);
    if(b)
    {
    	RequestDispatcher rd=req.getRequestDispatcher("register.html");
	rd.include(req,res);
	out.print("Resteration is Successfully Completed click here <a href=login.html>LOGIN</a>");
	
    }
    else
    {
    	 RequestDispatcher rd=req.getRequestDispatcher("registor.html");
		 rd.include(req,res);
			 out.print(" error ");
    }
}
	else if(path.equals("/reqallusers")) {

	
	try {
		ResultSet rs=new Dao().viewAll();
out.print("<body><table  border=4 cellpadding><tr bgcolor=red><td>name</td><td>Email Id</td><td>Password</td><td>mobile</td><td>city</td><td >updateuser</td><td>deleteuser</td></tr>");
	
		while(rs.next())
		{
			out.print("<body><tr bgcolor=yellow><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getLong(4)+"</td><td>"+rs.getString(5)+"</td><td bgcolor=white ><a href=requpdate?id="+rs.getString(1)+">UpdateUser</a></td><td bgcolor=white><a href=reqdel?t1="+rs.getString(1)+">DeleteUser</a></td></tr>");                             
		
		}
	} catch (Exception e) {
		System.out.println(e);
	}
	}
	else if(path.equals("/reqdel"))
	{
		
		
	  String name=req.getParameter("t1");
	
		boolean b=new Dao().delete(name);
		
		if(b){
			
			RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
			rd.forward(req,res);
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
			rd.forward(req,res);
			out.print("error occur");
			
		}}
	else if(path.equals("/requpdate"))
	{
	String name=req.getParameter("id");
		
		try {
			ResultSet rs=new Dao().view(name);
			
			if(rs.next())
			{

				out.print("<body><form action=update><table bgcolor=yellow border=7 cellpadding=5 ><tr><td>name:</td><td><input type=text  name=t1 readonly value="+rs.getString(1) +"> </td>");
				out.print("<tr><td>Email:    </td><td> <input      type=text name=t2         value="+rs.getString(2)+"></td> ");
				out.print("<tr><td>Pwd:       </td><td><input      type=text name=t3          value="+rs.getString(3)+"></td> ");
				out.print("<tr><td>MobileNO:  </td><td><input      type=text name=t4          value="+rs.getLong(4)+"></td> ");
				out.print("<tr><td>adr:      </td><td> <input      type=text name=t5          value="+rs.getString(5)+"></td> ");
				out.print("<tr><td><input type=submit value=Update></td><td><input type=Reset value=clear></td></form>");
			}
		}catch (Exception e) {
		
		}}
		else if(path.equals("/update"))	
		{	
		String name=req.getParameter("t1");
			String pwd=req.getParameter("t3");		
			String email=req.getParameter("t2");		
			long mobile=Long.parseLong(req.getParameter("t4"));
			String adr=req.getParameter("t5");
			boolean b=new Dao().update(name, email, pwd, mobile, adr);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
		    	rd.forward(req, res);
			}
			
			
		}
	
	
		
}}






























