import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginController extends HttpServlet
{
public void service(HttpServletRequest req,HttpServletResponse res) throws IOException 
{
Connection con=null;
ResultSet rs=null;
con=Dao.getConnectionObject();
PrintWriter out=res.getWriter();
try {
	Statement stmt=con.createStatement();
	 rs=stmt.executeQuery("select name,pwd from one where name='"+req.getParameter("t1")+"'and pwd='"+req.getParameter("t2")+"'");
	if(rs.next())
	{
	RequestDispatcher rd=req.getRequestDispatcher("Welcome.html");
	rd.include(req, res);
 
	}
	else {
		RequestDispatcher rd=req.getRequestDispatcher("login.html");
		rd.include(req, res);
		out.print("<center>Invalid username /password"); 
		}  
}
catch(Exception e) {System.out.println(e);}
}
}
