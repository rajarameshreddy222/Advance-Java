import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteUser extends HttpServlet{
	public void service( HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		PrintWriter out=res.getWriter();
	Connection con=null;
	con=Dao.getConnectionObject();
	int i=0;
	try {
		
	Statement pstmt=con.createStatement();
		i=pstmt.executeUpdate("delete from one where name='"+req.getParameter("t1")+"'");
		System.out.println(i);
        if(i>0)
           {
        	
        	out.print("deleted");
        	RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
        	rd.forward(req, res);
              }

          }
	catch(Exception e)
	{
		System.out.println(e);
	}
	
	}

}
