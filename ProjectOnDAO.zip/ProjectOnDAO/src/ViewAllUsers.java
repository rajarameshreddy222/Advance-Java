import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewAllUsers extends HttpServlet
{
	public void service( HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		PrintWriter out=res.getWriter();
	Connection con=null;
    ResultSet rs=null;
    con=Dao.getConnectionObject();
    try {
    	Statement stmt=con.createStatement();
    	rs=stmt.executeQuery("select * from one ");
    	 out.print("<body><table  border=4 cellpadding><tr bgcolor=red><td>name</td><td>Email Id</td><td>Password</td><td>mobile</td><td>city</td><td >updateuser</td><td>deleteuser</td></tr>");
    	while(rs.next())
    	{
    		
   out.print("<body><tr bgcolor=yellow><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getLong(4)+"</td><td>"+rs.getString(5)+"</td><td bgcolor=white ><a href=requpdate?id="+rs.getString(1)+">UpdateUser</a></td><td bgcolor=white><a href=reqdel?t1="+rs.getString(1)+">DeleteUser</a></td></tr>");                             
    		
   
    	}	
    }
    catch(Exception e) {System.out.println(e);}
	
		
	}

}
